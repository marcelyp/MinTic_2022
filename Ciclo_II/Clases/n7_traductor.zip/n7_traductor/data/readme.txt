La im�gen de los libros fue tomada de http://office.microsoft.com/clipart/default.aspx?lc=en-us

