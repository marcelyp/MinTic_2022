package codificacion;

public class nodo {
	
	//Atributos
	public String etiqueta;
	public int indice;
	public int t_i;
	public int t_f;
	public double coord_x;
	public double coord_y;
	
	//Métodos
	public void mostrarNodoConsola() {		
		System.out.printf("Nodo %d%n", this.indice);
		System.out.printf("Etiqueta %s%n", this.etiqueta);
		System.out.printf("Coordenadas Cartesianas (%f; %f)%n", this.coord_x, this.coord_y);
		System.out.printf("Ventana de Tiempo [%d; %d]%n", this.t_i, this.t_f);
		System.out.println();
	}
	
	//Constructores
	public nodo() {
		
		//Asignación de los parámetros recibidos a los atributos
		this.indice = 0;
		this.etiqueta = Integer.toString(this.indice);	
		this.coord_x = 0;
		this.coord_y = 0;
		this.t_i = 0;
		this.t_f = 0;		
		
	}
	
	public nodo(double x, double y) {
		
		//Asignación de los parámetros recibidos a los atributos
		this.indice = 0;
		this.etiqueta = Integer.toString(this.indice);	
		this.coord_x = x;
		this.coord_y = y;
		this.t_i = 0;
		this.t_f = 0;
		
		verificarInvariante();
		
	}
	
	public nodo(int indice, String etiqueta, double coord_x, double coord_y) {
		
		//Asignación de los parámetros recibidos a los atributos
		this.indice = indice;		
		if(etiqueta.isEmpty()) {
			this.etiqueta = Integer.toString(indice);		
		}else {
			this.etiqueta = etiqueta;			
		}		
		this.coord_x = coord_x;
		this.coord_y = coord_y;
		
	}
    
	//Traducción de coordenadas 1
	//Traducción de coordenadas 2
	
	///Invariante
	
	//Validaciones de la clase
	private boolean nodoEsValido() {
		boolean banderaValidez = true;
		if(this.indice < 0 || this.etiqueta.isEmpty()) {
			banderaValidez = false;
		}
		return banderaValidez;
	}
	
	private void verificarInvariante() {
		assert nodoEsValido():"Nodo inválido!";
	}

}//Fin de la clase nodo
