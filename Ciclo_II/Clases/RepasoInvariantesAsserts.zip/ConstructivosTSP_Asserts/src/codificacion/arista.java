package codificacion;
import java.lang.Math; 

public class arista {
	
	//Atributos
	public nodo i;
	public nodo j;
	public double distanciaEUC_2D;	
	
	//Métodos
	public void mostrarAristaConsola() {		
		System.out.printf("%s -- %s (distancia = %f) %n", this.i.etiqueta, this.j.etiqueta, this.distanciaEUC_2D);
		//System.out.println();
	}
	
	//Constructores	
	public arista(nodo i,nodo j) {
		
		//Asignación de los parámetros recibidos
		this.i = i;
		this.j = j;
		
		//Calcular distancia de la arista EUC_2D
		if(this.i.indice == this.j.indice) {
			distanciaEUC_2D = 0;		
		}else {
			distanciaEUC_2D = calcularEUC_2D();
		}				
		
	}	
	
	//Cálculo de la distancia entre los nodos de la arista
	public int calcularEUC_2D(){
		
		//Obtener las componentes de cada nodo
		double x_1 = this.i.coord_x;
		double x_2 = this.j.coord_x;
		double y_1 = this.i.coord_y;
		double y_2 = this.j.coord_y;
		
		//Cuadrado de las diferencias en x
		double cdx = Math.pow((x_2 - x_1),2);
		
		//Cuadrado de las diferencias en y
		double cdy = Math.pow((y_2 - y_1),2);		 
		
		//Retornar EUC_2D de la librería TSP
        return (int)(Math.sqrt( cdx + cdy ) + 0.5); 
    }
	
	
}
