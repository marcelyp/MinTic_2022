package codificacion;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files

public class red {
	
	//Atributos
	/////////
	
	public int numeroNodos;
	public int numeroAristas;
	public boolean grafoCompleto;
	public boolean grafoPlanar;
	public int[][] matrizAdyacencia;
	public nodo[] nodos;
	public arista[] aristas;
	
	//Métodos
	/////////
	
	//Método para añadir nodos a la red
    public void addNodo(nodo nuevoNodo){
    	
    	//Revisar el índice y etiqueta del nodo y reasignar si llega en 0
    	if(nuevoNodo.indice == 0) {
    		nuevoNodo.indice = this.numeroNodos + 1;
    		nuevoNodo.etiqueta = Integer.toString(nuevoNodo.indice);
    		this.numeroNodos++;
    	}    	
    	
    	//Validar si está vacío el listado de nodos
    	if(this.numeroNodos == 0) {
    		
    		//Inicializar los nodos de la red con el nodo recibido
    		nodo arr[] = { nuevoNodo };   		
            this.nodos = null;
            this.nodos = arr;
            
    	}else{
    		
    		//Calcular tamaño del arreglo recibido
        	int tamanioArreglo = this.nodos.length;  	
      
            //Arreglo nuevo con el nuevo tamaño
            nodo nuevoarreglo[] = new nodo[tamanioArreglo + 1]; 
      
            //Descargar todos los elementos que traía el contenedor de nodos
            for (int i = 0; i < tamanioArreglo; i++) 
            	nuevoarreglo[i] = this.nodos[i]; 
            
            //Agregar el nodo en la posición adicional que tiene la copia
            nuevoarreglo[tamanioArreglo] = nuevoNodo;
            
            //Actualizar el arreglo de nodos de la red
            this.nodos = null;//Limpiar la sección de memoria
            this.nodos = nuevoarreglo;//Asignarlo en el espacio de memoria
    		
    	}  	
        
    	//Revisar integridad de los nodos de la red
    	verificarRed();
    	
    }
    
    //Mostrar nodos de la red por consola
    public void mostrarNodosConsola(){
    	for(int i=0;i<this.numeroNodos;++i)
    		nodos[i].mostrarNodoConsola();
    }
    
    //Método para añadir aristas a la red
    public void addArista(arista nuevaArista){
    	
    	//Validar si está vacío el listado de nodos
    	if(this.numeroAristas == 0) {
    		
    		//Inicializar los nodos de la red con el nodo recibido
    		arista arr[] = { nuevaArista };   		
            this.aristas = null;
            this.aristas = arr;
            
    	}else{
    		
    		//Calcular tamaño del arreglo recibido
        	int tamanioArreglo = this.aristas.length;  	
      
            //Arreglo nuevo con el nuevo tamaño
            arista nuevoarreglo[] = new arista[tamanioArreglo + 1]; 
      
            //Descargar todos los elementos que traía el contenedor de aristas
            for (int i = 0; i < tamanioArreglo; i++) 
            	nuevoarreglo[i] = this.aristas[i]; 
            
            //Agregar la arista en la posición adicional que tiene la copia
            nuevoarreglo[tamanioArreglo] = nuevaArista;
            
            //Actualizar el arreglo de nodos de la red
            this.aristas = null;//Limpiar la sección de memoria
            this.aristas = nuevoarreglo;//Asignarlo en el espacio de memoria
    		
    	}       
        
    }
    
    //Mostrar aristas de la red por consola
    public void mostrarAristasConsola(){
    	for(int a=0;a<this.numeroAristas;++a)
    		aristas[a].mostrarAristaConsola();
    }
    
	//Constructores de la clase red (grafo)
	///////////////////////////////////////
	
	//Proveniente de un archivo
	public red(String rutaArchivo){	
		
		//Inicializar el número de nodos, ciudades, puntos, etc		
		this.numeroNodos = 0;
		this.numeroAristas = 0;
		
		//Intentar abrir el archivo recibido
		try {
			
		      File myObj = new File(rutaArchivo);
		      Scanner myReader = new Scanner(myObj);
		      while (myReader.hasNextLine()) {
		    	
		    	//Cargar los datos de cada una de las líneas
		        String data = myReader.nextLine();		        
		        
		        //Procesar las líneas del archivo		        
		        String[] arrOfStr = data.split(" ", -2);
		        
		        //Obtener longitud del arreglo obtenido por el Split
		        int longitudArreglo = arrOfStr.length;
		        
		        //Validar el número de elementos de cada línea
		        if(longitudArreglo == 3){
		        	
		        	//Extraer la información para crear los nodos
		        	//--------------------------------------------
		        	
		        	//Índice		        	
		        	int indice = Integer.parseInt(arrOfStr[0]);	        	
		        	
		        	//Etiqueta
		        	String etiqueta = arrOfStr[0];		        	
		        	
		        	//Componente en X
		        	double componenteX = Double.parseDouble(arrOfStr[1]);
		        			
        			//Componente en Y
		        	double componenteY = Double.parseDouble(arrOfStr[2]);
		        	
		        	//Creación del nodo con la información cargada
		        	
		        	//Adicionarlo a la red	        	
		        	this.addNodo(new nodo(indice, etiqueta, componenteX, componenteY));        	
		        	        	
        			//Por cada nodo identificado en la instancia, actualizar el atributo
    		        this.numeroNodos += 1;
		        	
		        }else {
		        	
		        	//Reportar el error en consola
		        	System.out.println("Problemas con la estructura de las coordenadas de los nodos!!!");
		        	
		        }	        
		        
		        //Salida de diagnóstico del split
		        //for (String a : arrOfStr) 
		        //   System.out.println(a); 
		        
		        //Mostrar las líneas leídas del archivo
		        //System.out.println(data);	
		        		        
		        
		      }
		      //Cierre del manejador del archivo
		      myReader.close();
		    } catch (FileNotFoundException e) {
		    	//Reportar el error de apertura
				System.out.println("Problemas abriendo el archivo.");
				e.printStackTrace();
		    }
		
		
		//Construir las aristas después de tener los nodos
		for(int i=0;i<this.numeroNodos;++i) {
			for(int j=0;j<this.numeroNodos;++j) {				
				this.addArista(new arista(this.nodos[i],this.nodos[j]));
				this.numeroAristas++;
			}			
		}
		
		
		//System.out.print("Constructor recibiendo ruta en desarrollo!");		
	}
	
	//Por código, recibiendo el parámetro y generando coordenadas aleatorias
	public red(int cantidadPuntos){
		
		//Especificar atributo correspondiente
		numeroNodos = cantidadPuntos;		
		
		//Crear todos los nodos de la red o grafo
		//(Coordenadas generadas aleatoriamente)
		for(int i=0;i<numeroNodos;++i){
						
		}
		
		
		
		//Crear todas las aristas de la red o grafo
		
		
		
		//Redimensión e inicialización de la matriz de adyacencia
		//Java garantiza el valor 0 cuando los elementos son integer
		matrizAdyacencia = new int[numeroNodos][];        
        for (int i = 0; i < numeroNodos ; i++) {
        	matrizAdyacencia[i] = new int[numeroNodos];
        }     
		
		
	}//Fin del constructor por parámetro
	
	//Invariantes
	private boolean nodoAniadidoSinRepetir() {
		boolean banderaSinRepeticiones = true;
		if(this.nodos.length>0) {
			nodo nodoAniadido = this.nodos[this.nodos.length-1];
			for(int i = 0; i<this.nodos.length-1;++i) {
				//Componentes iguales
				if(this.nodos[i].coord_x == nodoAniadido.coord_x && this.nodos[i].coord_y == nodoAniadido.coord_y){
					banderaSinRepeticiones = false;
					break;
				}
			}			
		}
		
		return banderaSinRepeticiones;	
	}
	
	private void verificarRed() {
		assert nodoAniadidoSinRepetir():"Ubicación repetida!";
	}
	
	
	

}//Fin de la clase
