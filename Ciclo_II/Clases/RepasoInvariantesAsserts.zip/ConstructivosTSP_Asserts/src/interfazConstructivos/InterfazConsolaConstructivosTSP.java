package interfazConstructivos;

import codificacion.red;
import codificacion.nodo;
import codificacion.arista;
import java.util.Scanner;

public class InterfazConsolaConstructivosTSP {	
	
	//Atributos de la interfaz
	public red redTSP;	
	//public nodo nodo1;	
	
	//Métodos de la interfaz
	
	//Constructor de la interfaz
	public InterfazConsolaConstructivosTSP(String rutaArchivo) {
		
		//Inicializar los objetos del caso de estudio
		redTSP = new red(rutaArchivo);
		
		//Mostrar los nodos de la red
		//redTSP.mostrarNodosConsola();
		
		//Escuchar los eventos (consola)
		boolean mainloop = true;
		Scanner teclado = new Scanner(System.in);
		int opcion;
		while(mainloop) {
			
			System.out.printf("--- Menú ---%n");
			System.out.printf("1 - Mostrar Nodos%n");
			System.out.printf("2 - Mostrar Aristas%n");
			System.out.printf("3 - Agregar Nodo%n");
			System.out.printf("4 - Salir%n");
			System.out.printf("Ingresar opción: ");		
			opcion = teclado.nextInt();				
			if(opcion == 1) {
				redTSP.mostrarNodosConsola();				
			}else if(opcion == 2) {
				redTSP.mostrarAristasConsola();
			}else if(opcion == 3) {				
				System.out.printf("Ingresar x = ");				
				int coord_x = teclado.nextInt();
				System.out.printf("Ingresar y = ");				
				int coord_y = teclado.nextInt();				
				nodo nodoIngresado = new nodo(coord_x,coord_y);
				redTSP.addNodo(nodoIngresado);				
				redTSP.mostrarNodosConsola();		
			}else if(opcion == 4) {
				System.out.print("Salida!");
				mainloop = false;
			}			
			
		}//Fin del mainloop
		teclado.close();
		
		
	}
	
	
	//Main - Inicio de la aplicación por consola
    public static void main( String[] pArgs ){
    	
    	//Ruta especificada por código (alterno a los argumentos de la línea de comandos)
    	String rutaArchivo = "/Users/luismiguelescobarfalcon/eclipse-workspace/ConstructivosTSP/data/eil51.tsp";
    	//String rutaArchivo = "../../data/eil51.tsp";
    	//String rutaArchivo = "../../data/st70.tsp";   	
    	
    	//Crear la interfaz tipo consola
    	InterfazConsolaConstructivosTSP interfaz = new InterfazConsolaConstructivosTSP(rutaArchivo);
    	
    	    	
    	
    	//Pruebas mundo creado
    	//nodo nodo1 = new nodo( );    	
    	//nodo1.mostrarNodoConsola();
    	
    	
        
    }

}
